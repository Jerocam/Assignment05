//STEP 1
/*let movies = ["The Terminator", "Alien3", "Twelve Monkey", "Jurassic Park", "Blade Runner 2049"]
window.console.log(movies[2]);
*/
//STEP 2
/*let movies = [];
movies[0] = "Back to the Future";
movies[1] = "Back to the Future2";
movies[2] = "Aliens";
movies[3] = "Star Wars Episode III";
movies[4] = "Nemesis Evangelion";

window.console.log(movies[0]);*/

//STEP 3
/*let movies = [];

movies[0] = "Back to the Future";
movies[1] = "Back to the Future2";
movies[2] = "Aliens";
movies[3] = "Star Wars Episode III";
movies[4] = "Nemesis Evangelion";
movies[movies.length] = "Final Fantasy Within the Spirit";

window.console.log(movies.length);*/

//STEP 4
/*let movies = ["Ace Venture", "Alien", "The Terminator 2", "Rocky", "RockyII"];
movies.shift();

movies.forEach(function(movies){
    window.console.log(movies);
});*/

//STEP 5
/*let movies = ["Resident Evil","Rambo","Ace Venture", "Alien", "The Terminator 2", "Rocky", "RockyII"];

let i;
for(i=0;i<movies.length;i++){
    window.console.log(movies[i]);
}
*/
//STEP 6
/*let movies = ["Resident Evil","Rambo","Ace Venture", "Alien", "The Terminator 2", "Rocky", "RockyII"];
let favMovies;

for(favMovies in movies){
    window.console.log(movies[favMovies]);
}
*/
//STEP 7
/*let movies = ["Resident Evil","Rambo","Ace Venture", "Alien", "The Terminator 2", "Rocky", "RockyII"];
let favMovies;

for(favMovies in movies){
    window.console.log(movies.sort()[favMovies]);
}*/

//STEP 8
let movies = ["Resident Evil","Rambo","Ace Venture", "Alien", "The Terminator 2", "Rocky", "RockyII"];
let favMovies;
let leastFavMovies = movies[1,3,4];

window.console.log("Movies I like: ")
for(favMovies in movies){
    favMovies = movies[0,2,5,6];
    window.console.log(movies[favMovies]);
}

window.console.log("Movies I regret watching: ")
for(leastFavMovies in movies){
    window.console.log(movies[leastFavMovies]);
}


//STEP 9

//STEP 10

//STEP 11

//STEP 12

//STEP 13

//STEP 14

//STEP 15

//STEP 16

//STEP 17

//STEP 18

//STEP 19

//STEP 20